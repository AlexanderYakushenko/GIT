package by.issoft.street;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Flats extends AppDetails {


    //Class flat{ double square. Int num....}

    public flat(double square, int number) {
        super(square, number);
    }
//
//    public static String appartments() {
//
//        List<String> totalAppartments = new ArrayList();
//        Integer all = totalAppartments.addAll(Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15));
//     //   Class Street { List<House> houses ...}. Class House { list<flat> flats. Class flat{ double square. Int num....}
//    }
//    public Flats(int s, int q) {
//        super(s, q);
//    }
}
