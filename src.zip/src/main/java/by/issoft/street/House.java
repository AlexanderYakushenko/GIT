package by.issoft.street;

import java.util.ArrayList;

public class House extends AppDetails{

    //public static String house;
    //private String house;


    public House(double square, int number) {
        super(square, number);
    }

    public void setHouse(String house) {
        House.house = house;
    }

    //    ArrayList<Appartments> multiApp = new ArrayList<Appartments>();
//
//
//
//    House taunhouse = new House();
//    House privHouse = new House();


}
