package by.issoft.street;

import org.apache.commons.collections4.CollectionUtils;

public class AppTaxCalculating {


return taxes;


    public static double appTax() {

        AppDetails square;
        AppDetails number;
        AppDetails k;
        double tax = CollectionUtils.union(totalFlats, totalHouse, totalTownHouse);
        return tax;
    }

//    public void taxForOne (double k, int s){
//        double onePerson = (s/k);
//    }

//    public void taxForAny (double k, int s, int q){
//        double onePerson = ((s*q)/k);
//
//    }
    public void printCalculation (){

        System.out.println( "Total appartment TAX for the street is: " + tax);
    }

}
