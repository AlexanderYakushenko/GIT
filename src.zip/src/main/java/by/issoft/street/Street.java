package by.issoft.street;


import java.util.ArrayList;
import java.util.List;


public class Street {

        public static void main(String[] args) {}


        public static street(){

             //List<House>  houses = new ArrayList<>(new House(90.5,4));
                //ArrayList houses = new ArrayList<>(new House(90.5,4));

                Class Street = new Street(){ List<House> houses ...}.


                //Class House { list<flat> flats.
                //Class flat{ double square. Int num....}
//                House multiApp = new House();
//                House tawnhouse = new House();
//                House privHouse = new House();

        }










}
