package by.issoft.street;

import com.sun.org.apache.xpath.internal.operations.String;
import sun.plugin.javascript.navig.Array;
import java.util.*;
import java.util.Arrays;
import java.util.List;

public class TownHouse {
//
//     public static String townHouse;
//     //  townHouse = new String appType;
//
//    List<Integer> townHouseApp = new Arrays.asList();
//    townHouseApp.addAll(Arrays.asList("App1", "App2", App3));
//
//    public TownHouse(int s, int q, String appType) {
//        super(s, q);
//
//    }
//
//    public static void setTownHouse(String townHouse) {
//        TownHouse.townHouse = townHouse;
//    }
}
