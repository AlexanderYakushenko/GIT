package by.issoft.street;

import com.sun.org.apache.xpath.internal.operations.String;

public abstract class AppDetails {


     double square;  // площадь квартиры
     int number;   // кол-во людей
     double k;  //коэфицент
     String appType;  /* тип жилья */

    public AppDetails (double square, int number) {

        this.square = square;
        this.number = number;
        //this.k = k;

//        if (String appType = House.house){
//            k = new k (0.1);
//        } if (String appType = TownHouse.townHouse){
//            k = new k (0.3);
//        } else (String appType = Flats.appartments){
//            k = new k (0.5);
//        }
//        return appType;

    }

//    public void taxForOne (double k, int s){
//        double onePerson = ((s*1)/k);
//
//    }

}
